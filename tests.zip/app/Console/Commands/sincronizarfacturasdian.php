<?php

namespace App\Console\Commands;

use App\Models\Factura;
use Illuminate\Console\Command;

class sincronizarfacturasdian extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:sincronizarfacturas';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Proceso que toma las facturas de miggo y las sincroniza con la Dian';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {

        $id = 4;
		$data = Factura::select()
                ->where( 'facturas.id', '=', $id )
                ->get();

  	print_r($data);
    }
}
